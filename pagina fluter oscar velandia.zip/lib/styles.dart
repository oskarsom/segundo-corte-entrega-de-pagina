
import 'package:flutter/cupertino.dart';

abstract class Styles {
  static const TextStyle productRowItemName = TextStyle(
    color: Color.fromARGB(244, 129, 111, 4),//texto productos
    fontSize: 24,
    fontStyle: FontStyle.normal,
    fontWeight: FontWeight.normal,
  );

  static const TextStyle productRowTotal = TextStyle(
    color: Color.fromARGB(204, 211, 11, 11),
    fontSize: 18,
    fontStyle: FontStyle.normal,
    fontWeight: FontWeight.bold,
  );

  static const TextStyle productRowItemPrice = TextStyle(
    color: Color.fromARGB(255, 70, 11, 8),//texto valor de juego
    fontSize: 18,
    fontWeight: FontWeight.w300,
  );

  static const TextStyle searchText = TextStyle(
    color: Color.fromARGB(255, 246, 252, 246),//letra barra de busqueda
    fontSize: 14,
    fontStyle: FontStyle.normal,
    fontWeight: FontWeight.normal,
  );

  static const TextStyle deliveryTimeLabel = TextStyle(
    color: Color.fromARGB(255, 10, 95, 7),//tiempo de entrega
    fontWeight: FontWeight.w300,
  );

  static const TextStyle deliveryTime = TextStyle(
    color: Color.fromARGB(255, 4, 100, 9),
  );

  static const Color productRowDivider = Color.fromARGB(255, 197, 11, 11);

  static const Color scaffoldBackground = Color.fromARGB(255, 182, 19, 19);

  static const Color searchBackground = Color.fromARGB(255, 138, 8, 8);//barra de filtro

  static const Color searchCursorColor = Color.fromARGB(255, 242, 243, 235);

  static const Color searchIconColor = Color.fromARGB(255, 29, 4, 4);
}
